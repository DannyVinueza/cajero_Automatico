public class Cajero {
    String titular;
    double saldo;
    public void vehiculos(){
        titular = "Danny Vinueza";
        saldo = 200.14;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
